﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Enter the number of values: ");
        int n = Convert.ToInt32(Console.ReadLine());

        int[] numbers = new int[n];

        Console.WriteLine($"Enter {n} numbers:");
        for (int i = 0; i < n; i++)
        {
            numbers[i] = Convert.ToInt32(Console.ReadLine());
        }

        double average = CalculateAverage(numbers);
        Console.WriteLine($"The average of numbers {string.Join(" ", numbers)} is {average}");
    }

    static double CalculateAverage(int[] array)
    {
        int sum = 0;
        foreach (int num in array)
        {
            sum += num;
        }
        return (double)sum / array.Length;
    }
}