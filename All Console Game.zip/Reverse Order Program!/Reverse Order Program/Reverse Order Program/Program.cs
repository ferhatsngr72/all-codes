﻿using System;

class Program
{
    static void Main()
    {
        int[] numbers = new int[20];

        Console.WriteLine("Enter 20 numbers:");
        for (int i = 0; i < 20; i++)
        {
            numbers[i] = Convert.ToInt32(Console.ReadLine());
        }

        Console.WriteLine("Numbers in reverse order:");
        for (int i = 19; i >= 0; i--)
        {
            Console.Write(numbers[i] + " ");
        }
    }
}