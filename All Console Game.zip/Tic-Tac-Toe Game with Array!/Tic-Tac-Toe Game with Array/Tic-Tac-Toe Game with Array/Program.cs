﻿using System;

class TicTacToe
{
    static char[,] board =
    {
        {'1', '2', '3'},
        {'4', '5', '6'},
        {'7', '8', '9'}
    };

    static int player = 1; // By default, player 1 starts
    static int choice; // User choice for position to mark

    static void Main()
    {
        do
        {
            Console.Clear(); // Clear console for a new move
            Console.WriteLine("Player {0}, your move!", player % 2 == 0 ? 2 : 1);
            DrawBoard();
            ChoosePosition();

            if (CheckForWin())
            {
                Console.Clear();
                DrawBoard();
                Console.WriteLine("Player {0} wins!", player % 2 == 0 ? 2 : 1);
                break;
            }
            else if (CheckForTie())
            {
                Console.Clear();
                DrawBoard();
                Console.WriteLine("It's a tie!");
                break;
            }

            player++; // Switch to the next player
        } while (true);
    }

    static void DrawBoard()
    {
        for (int row = 0; row < 3; row++)
        {
            for (int col = 0; col < 3; col++)
            {
                Console.Write($"  {board[row, col]}  ");
                if (col < 2) Console.Write("|");
            }
            Console.WriteLine();
            if (row < 2) Console.WriteLine("_____|_____|_____");
        }
    }

    static void ChoosePosition()
    {
        bool validInput = false;

        do
        {
            Console.Write("Enter a number (1-9) to place your mark: ");
            string input = Console.ReadLine();

            if (int.TryParse(input, out choice))
            {
                if (choice >= 1 && choice <= 9 && IsPositionAvailable())
                {
                    validInput = true;
                    MarkBoard();
                }
                else
                {
                    Console.WriteLine("Invalid move. Try again.");
                }
            }
            else
            {
                Console.WriteLine("Invalid input. Enter a number (1-9).");
            }
        } while (!validInput);
    }

    static bool IsPositionAvailable()
    {
        int row = (choice - 1) / 3;
        int col = (choice - 1) % 3;
        return board[row, col] != 'X' && board[row, col] != 'O';
    }

    static void MarkBoard()
    {
        char marker = (player % 2 == 0) ? 'O' : 'X';
        int row = (choice - 1) / 3;
        int col = (choice - 1) % 3;
        board[row, col] = marker;
    }

    static bool CheckForWin()
    {
        // Check rows, columns, and diagonals for a win
        return CheckRows() || CheckColumns() || CheckDiagonals();
    }

    static bool CheckRows()
    {
        for (int row = 0; row < 3; row++)
        {
            if (board[row, 0] == board[row, 1] && board[row, 1] == board[row, 2])
            {
                return true;
            }
        }
        return false;
    }

    static bool CheckColumns()
    {
        for (int col = 0; col < 3; col++)
        {
            if (board[0, col] == board[1, col] && board[1, col] == board[2, col])
            {
                return true;
            }
        }
        return false;
    }

    static bool CheckDiagonals()
    {
        return (board[0, 0] == board[1, 1] && board[1, 1] == board[2, 2]) ||
               (board[0, 2] == board[1, 1] && board[1, 1] == board[2, 0]);
    }

    static bool CheckForTie()
    {
        // Check if all positions are marked and no player has won
        for (int row = 0; row < 3; row++)
        {
            for (int col = 0; col < 3; col++)
            {
                if (board[row, col] != 'X' && board[row, col] != 'O')
                {
                    return false;
                }
            }
        }
        return true;
    }
}
