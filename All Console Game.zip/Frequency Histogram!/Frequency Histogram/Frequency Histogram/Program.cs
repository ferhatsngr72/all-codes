﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        Console.Write("How many numbers do you want to enter: ");
        int n = Convert.ToInt32(Console.ReadLine());

        Dictionary<int, int> frequency = new Dictionary<int, int>();

        for (int i = 1; i <= n; i++)
        {
            Console.Write($"Enter number {i}: ");
            int number = Convert.ToInt32(Console.ReadLine());

            if (number >= 1 && number <= 5)
            {
                if (frequency.ContainsKey(number))
                {
                    frequency[number]++;
                }
                else
                {
                    frequency[number] = 1;
                }
            }
            else
            {
                Console.WriteLine("Number out of range. Enter a number between 1 and 5.");
                i--;
            }
        }

        DrawHistogram(frequency);
    }

    static void DrawHistogram(Dictionary<int, int> frequency)
    {
        Console.WriteLine("Frequency Histogram:");

        for (int i = 1; i <= 5; i++)
        {
            Console.Write($"{i}: ");
            if (frequency.ContainsKey(i))
            {
                for (int j = 0; j < frequency[i]; j++)
                {
                    Console.Write("*");
                }
            }
            Console.WriteLine();
        }
    }
}
